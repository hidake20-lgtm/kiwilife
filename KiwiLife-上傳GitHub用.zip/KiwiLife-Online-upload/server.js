// Kiwi Life Online — Hanmer Springs 多人伺服器 (Colyseus)
const path = require('path');
const express = require('express');
const { createServer } = require('http');
const { Server, Room } = require('colyseus');
const { WebSocketTransport } = require('@colyseus/ws-transport');

const app = express();
app.use(express.static(path.join(__dirname, 'public')));

const httpServer = createServer(app);
const gameServer = new Server({
  transport: new WebSocketTransport({ server: httpServer })
});

class TownRoom extends Room {
  onCreate() {
    this.maxClients = 40;
    this.players = {};
    // 玩家位置更新
    this.onMessage('move', (client, d) => {
      const p = this.players[client.sessionId];
      if (p && d) {
        p.x = +d.x || 0;
        p.y = +d.y || 0;
        p.dir = ['d','l','r','u'].includes(d.dir) ? d.dir : 'd';
        p.m = !!d.m;
      }
    });
    // 聊天廣播
    this.onMessage('chat', (client, t) => {
      t = String(t || '').slice(0, 80).trim();
      if (!t) return;
      const p = this.players[client.sessionId];
      this.broadcast('chat', { id: client.sessionId, name: p ? p.name : '?', t });
    });
    // 每 100ms 廣播所有玩家狀態
    this.clock.setInterval(() => this.broadcast('st', this.players), 100);
  }
  onJoin(client, options) {
    options = options || {};
    this.players[client.sessionId] = {
      x: 1088, y: 1376, dir: 'd', m: false,
      name: String(options.name || 'Kiwi').slice(0, 12),
      skin: (options.skin | 0) % 6
    };
    console.log('[join]', client.sessionId, this.players[client.sessionId].name);
  }
  onLeave(client) {
    console.log('[leave]', client.sessionId);
    delete this.players[client.sessionId];
  }
}

gameServer.define('town', TownRoom);

const PORT = process.env.PORT || 2567;
gameServer.listen(PORT).then(() => {
  console.log('==========================================');
  console.log(' Kiwi Life Online 伺服器已啟動！');
  console.log(' 本機遊玩：http://localhost:' + PORT);
  console.log(' 同 WiFi 朋友：http://<你的IP>:' + PORT);
  console.log('==========================================');
});
